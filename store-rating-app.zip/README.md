# Store Rating App

Instructions to run both backend and frontend.